from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from swagger_client.api.articles_api import ArticlesApi
from swagger_client.api.authors_api import AuthorsApi
from swagger_client.api.collections_api import CollectionsApi
from swagger_client.api.institutions_api import InstitutionsApi
from swagger_client.api.other_api import OtherApi
from swagger_client.api.projects_api import ProjectsApi
