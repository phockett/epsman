# ProjectNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Project note id | [optional] 
**user_id** | **int** | User who wrote the note | [optional] 
**abstract** | **str** | Note Abstract - short/truncated content | [optional] 
**user_name** | **str** | Username of the one who wrote the note | [optional] 
**created_date** | **str** | Date when note was created | [optional] 
**modified_date** | **str** | Date when note was last modified | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


