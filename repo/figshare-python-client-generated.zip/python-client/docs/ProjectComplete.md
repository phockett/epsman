# ProjectComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **str** | Project funding | [optional] 
**funding_list** | [**list[FundingInformation]**](FundingInformation.md) | Full Project funding information | [optional] 
**description** | **str** | Project description | [optional] 
**collaborators** | [**list[Collaborator]**](Collaborator.md) | List of project collaborators | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


