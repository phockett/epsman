# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | User id | [optional] 
**first_name** | **str** | First Name | [optional] 
**last_name** | **str** | Last Name | [optional] 
**name** | **str** | Full Name | [optional] 
**is_active** | **bool** | Account activity status | [optional] 
**url_name** | **str** | Name that appears in website url | [optional] 
**is_public** | **bool** | Account public status | [optional] 
**job_title** | **str** | User Job title | [optional] 
**orcid_id** | **str** | Orcid associated to this User | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


