# PrivateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**viewer_type** | **str** | File viewer type | [optional] 
**preview_state** | **str** | File preview state | [optional] 
**upload_url** | **str** | Upload url for file | [optional] 
**upload_token** | **str** | Token for file upload | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


