# AuthorComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**institution_id** | **int** | Institution id | [optional] 
**group_id** | **int** | Group id | [optional] 
**first_name** | **str** | First Name | [optional] 
**last_name** | **str** | Last Name | [optional] 
**is_public** | **int** | if 1 then the author has published items | [optional] 
**job_title** | **str** | Job title | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


