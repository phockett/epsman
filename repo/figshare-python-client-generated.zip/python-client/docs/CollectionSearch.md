# CollectionSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_doi** | **str** | Only return collections with this resource_doi | [optional] 
**doi** | **str** | Only return collections with this doi | [optional] 
**handle** | **str** | Only return collections with this handle | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


