# ArticleComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**figshare_url** | **str** | Article public url | [optional] 
**files** | [**list[PublicFile]**](PublicFile.md) | List of article files | [optional] 
**authors** | [**list[Author]**](Author.md) | List of article authors | [optional] 
**custom_fields** | [**list[CustomArticleField]**](CustomArticleField.md) | List of custom fields values | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


