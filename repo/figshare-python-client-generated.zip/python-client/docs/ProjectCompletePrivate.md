# ProjectCompletePrivate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | **str** | Project funding | [optional] 
**funding_list** | [**list[FundingInformation]**](FundingInformation.md) | Full Project funding information | [optional] 
**description** | **str** | Project description | [optional] 
**collaborators** | [**list[Collaborator]**](Collaborator.md) | List of project collaborators | [optional] 
**quota** | **int** | Project quota | [optional] 
**used_quota** | **int** | Project used quota | [optional] 
**created_date** | **str** | Date when project was created | [optional] 
**modified_date** | **str** | Date when project was last modified | [optional] 
**used_quota_private** | **int** | Project private quota used | [optional] 
**used_quota_public** | **int** | Project public quota used | [optional] 
**group_id** | **int** | Group of project if any | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


