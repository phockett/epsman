# ProjectArticle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**citation** | **str** | Article citation | [optional] 
**confidential_reason** | **str** | Confidentiality reason | [optional] 
**is_confidential** | **bool** | Article Confidentiality | [optional] 
**size** | **int** | Article size | [optional] 
**funding** | **str** | Article funding | [optional] 
**funding_list** | **list[int]** |  | [optional] 
**tags** | **list[str]** | List of article tags | [optional] 
**version** | **int** | Article version | [optional] 
**is_active** | **bool** | True if article is active | [optional] 
**is_metadata_record** | **bool** | True if article has no files | [optional] 
**metadata_reason** | **str** | Article metadata reason | [optional] 
**status** | **str** | Article status | [optional] 
**description** | **str** | Article description | [optional] 
**is_embargoed** | **bool** | True if article is embargoed | [optional] 
**is_public** | **bool** | True if article is published | [optional] 
**created_date** | **str** | Date when article was created | [optional] 
**has_linked_file** | **bool** | True if any files are linked to the article | [optional] 
**categories** | [**list[Category]**](Category.md) | List of categories selected for the article | [optional] 
**license** | [**License**](License.md) | Article selected license | [optional] 
**embargo_reason** | **str** | Reason for embargo | [optional] 
**references** | **list[str]** | List of references | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


