# Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Role id | [optional] 
**name** | **str** | Role name | [optional] 
**category** | **str** | Role category | [optional] 
**description** | **str** | Role description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


