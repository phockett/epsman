# CollectionComplete

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funding** | [**list[FundingInformation]**](FundingInformation.md) | Full Collection funding information | [optional] 
**resource_id** | **str** | Collection resource id | [optional] 
**resource_doi** | **str** | Collection resource doi | [optional] 
**resource_title** | **str** | Collection resource title | [optional] 
**resource_link** | **str** | Collection resource link | [optional] 
**resource_version** | **int** | Collection resource version | [optional] 
**version** | **int** | Collection version | [optional] 
**description** | **str** | Collection description | [optional] 
**categories** | [**list[Category]**](Category.md) | List of collection categories | [optional] 
**references** | **list[str]** | List of collection references | [optional] 
**tags** | **list[str]** | List of collection tags | [optional] 
**authors** | [**list[Author]**](Author.md) | List of collection authors | [optional] 
**institution_id** | **int** | Collection institution | [optional] 
**group_id** | **int** | Collection group | [optional] 
**articles_count** | **int** | Number of articles in collection | [optional] 
**public** | **bool** | True if collection is published | [optional] 
**citation** | **str** | Collection citation | [optional] 
**custom_fields** | [**list[CustomArticleField]**](CustomArticleField.md) | Collection custom fields | [optional] 
**modified_date** | **str** | Date when collection was last modified | [optional] 
**created_date** | **str** | Date when collection was created | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


