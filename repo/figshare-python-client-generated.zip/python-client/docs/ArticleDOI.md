# ArticleDOI

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doi** | **str** | Reserved DOI | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


